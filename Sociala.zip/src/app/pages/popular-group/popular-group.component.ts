import { Component } from '@angular/core';

@Component({
  selector: 'app-popular-group',
  templateUrl: './popular-group.component.html',
  styleUrls: ['./popular-group.component.scss']
})
export class PopularGroupComponent {

}
