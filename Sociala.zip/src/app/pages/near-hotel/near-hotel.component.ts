import { Component } from '@angular/core';

@Component({
  selector: 'app-near-hotel',
  templateUrl: './near-hotel.component.html',
  styleUrls: ['./near-hotel.component.scss']
})
export class NearHotelComponent {

}
