import { Component } from '@angular/core';

@Component({
  selector: 'app-helpbox',
  templateUrl: './helpbox.component.html',
  styleUrls: ['./helpbox.component.scss']
})
export class HelpboxComponent {

}
