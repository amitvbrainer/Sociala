import { Component } from '@angular/core';

@Component({
  selector: 'app-latest-event',
  templateUrl: './latest-event.component.html',
  styleUrls: ['./latest-event.component.scss']
})
export class LatestEventComponent {

}
