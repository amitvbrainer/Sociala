import { Component } from '@angular/core';

@Component({
  selector: 'app-social-netwotk',
  templateUrl: './social-netwotk.component.html',
  styleUrls: ['./social-netwotk.component.scss']
})
export class SocialNetwotkComponent {

}
